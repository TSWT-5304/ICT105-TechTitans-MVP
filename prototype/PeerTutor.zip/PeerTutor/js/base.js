(function () {
    function ready(fn) {
        if (document.readyState !== 'loading') fn();
        else document.addEventListener('DOMContentLoaded', fn);
    }

    ready(function () {
        document.querySelectorAll('nav.dash-nav, nav.nav').forEach(function (nav) {
            if (nav.dataset.mobileReady === 'true') return;
            nav.dataset.mobileReady = 'true';

            var links = nav.querySelector('.dash-nav-links, .nav-links');
            var actions = nav.querySelector('.dash-nav-right, .dash-nav-right-fixed, .nav-actions');
            if (!links && !actions) return;

            var toggle = document.createElement('button');
            toggle.type = 'button';
            toggle.className = 'mobile-nav-toggle';
            toggle.setAttribute('aria-label', 'Open menu');
            toggle.setAttribute('aria-expanded', 'false');
            toggle.innerHTML = '<span></span><span></span><span></span>';

            var panel = document.createElement('div');
            panel.className = 'mobile-nav-panel';

            var mobileLinks = document.createElement('div');
            mobileLinks.className = 'mobile-nav-links';
            if (links) {
                links.querySelectorAll('a').forEach(function (a) {
                    mobileLinks.appendChild(a.cloneNode(true));
                });
            }

            var mobileActions = document.createElement('div');
            mobileActions.className = 'mobile-nav-actions';
            if (actions) {
                actions.querySelectorAll('a, button').forEach(function (item) {
                    mobileActions.appendChild(item.cloneNode(true));
                });
            }

            panel.appendChild(mobileLinks);
            if (mobileActions.children.length) panel.appendChild(mobileActions);
            nav.appendChild(toggle);
            nav.appendChild(panel);

            toggle.addEventListener('click', function () {
                var isOpen = nav.classList.toggle('mobile-menu-open');
                toggle.setAttribute('aria-expanded', String(isOpen));
                toggle.setAttribute('aria-label', isOpen ? 'Close menu' : 'Open menu');
                document.body.classList.toggle('mobile-nav-active', isOpen);
            });

            panel.addEventListener('click', function (event) {
                if (event.target.closest('a')) {
                    nav.classList.remove('mobile-menu-open');
                    toggle.setAttribute('aria-expanded', 'false');
                    toggle.setAttribute('aria-label', 'Open menu');
                    document.body.classList.remove('mobile-nav-active');
                }
            });
        });
    });
})();

function handleSubscribe() {
    const email = document.getElementById('sub-email').value;
    if (!email || !email.includes('@')) {
        document.getElementById('sub-email').style.borderColor = '#f87171';
        return;
    }
    document.getElementById('sub-email').value = '';
    document.getElementById('sub-success').style.display = 'block';
}

function handleContact(btn) {
    btn.textContent = 'Sending...';
    btn.disabled = true;
    setTimeout(() => {
        btn.innerHTML = '<i class="ti ti-circle-check" style="margin-right:6px;"></i> Message Sent!';
        btn.style.background = '#22c55e';
        document.getElementById('form-success').style.display = 'block';
    }, 1000);
}

function filterTutors() {
    const query = document.getElementById('search-input').value.toLowerCase();
    const cards = document.querySelectorAll('.browse-card');
    let visible = 0;
    cards.forEach(card => {
        const text = card.innerText.toLowerCase();
        const match = text.includes(query);
        card.style.display = match ? '' : 'none';
        if (match) visible++;
    });
    document.getElementById('count').textContent = visible;
}

/* ── Tab switching ── */
function switchTab(name, btn) {
    document.querySelectorAll('.admin-tab, .tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById('tab-' + name).classList.add('active');
}

/* ── Table search ── */
function filterTable(input, tableId) {
    const q = input.value.toLowerCase();
    document.querySelectorAll('#' + tableId + ' tbody tr').forEach(row => {
        row.style.display = row.innerText.toLowerCase().includes(q) ? '' : 'none';
    });
}

/* ── Application actions ── */
function approveApp(btn) {
    const card = btn.closest('.app-card');
    card.style.opacity = '0.4';
    card.style.pointerEvents = 'none';
    btn.textContent = '✓ Approved';
    btn.style.background = '#dcfce7';
    btn.style.color = '#16a34a';
    updateBadge(-1);
}
function rejectApp(btn) {
    const card = btn.closest('.app-card');
    card.style.opacity = '0.4';
    card.style.pointerEvents = 'none';
    btn.textContent = '✗ Rejected';
    updateBadge(-1);
}
function updateBadge(delta) {
    const badge = document.querySelector('.tab-badge');
    let n = parseInt(badge.textContent) + delta;
    badge.textContent = Math.max(0, n);
}

function setTopic(btn) {
    document.querySelectorAll('.topic-tab').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
}

function updateChar(el) {
    document.getElementById('char-count').textContent = el.value.length;
}

function handleAttach(input) {
    if (!input.files.length) return;
    const area = document.getElementById('attach-area');
    const name = document.getElementById('attach-name');
    area.classList.add('has-file');
    name.textContent = '✓ ' + input.files[0].name;
    name.style.display = 'block';
}

function handleSend() {
    const fname = document.getElementById('fname').value.trim();
    const email = document.getElementById('email').value.trim();
    const subject = document.getElementById('subject').value;
    const message = document.getElementById('message').value.trim();
    const privacy = document.getElementById('privacy').checked;

    if (!fname || !email || !subject || !message) {
        alert('Please fill in all required fields.');
        return;
    }
    if (!privacy) {
        alert('Please agree to the Privacy Policy to continue.');
        return;
    }

    const btn = document.getElementById('btn-send');
    btn.innerHTML = '<i class="ti ti-loader-2" style="animation:spin 1s linear infinite;"></i> Sending...';
    btn.disabled = true;

    setTimeout(() => {
        btn.style.display = 'none';
        document.getElementById('send-success').style.display = 'flex';
    }, 1200);
}

/* ── Countdown timer ── */
let seconds = 600;
const timer = setInterval(() => {
    seconds--;
    const m = Math.floor(seconds / 60).toString().padStart(2, '0');
    const s = (seconds % 60).toString().padStart(2, '0');
    const el = document.getElementById('countdown');
    if (el) el.textContent = m + ':' + s;
    if (seconds <= 0) {
        clearInterval(timer);
        if (el) el.textContent = '00:00';
    }
}, 1000);

/* ── Payment method ── */
function selectMethod(method, btn) {
    document.querySelectorAll('.pay-method-tab').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.pay-method-panel').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById('panel-' + method).classList.add('active');
}

/* ── Card selection ── */
function selectCard(el) {
    document.querySelectorAll('.saved-card').forEach(c => c.classList.remove('selected'));
    el.classList.add('selected');
    document.getElementById('new-card-form').style.display = 'none';
}

function toggleNewCard() {
    document.querySelectorAll('.saved-card').forEach(c => c.classList.remove('selected'));
    const form = document.getElementById('new-card-form');
    form.style.display = form.style.display === 'none' ? 'block' : 'none';
}

/* ── Card number formatting ── */
function formatCard(input) {
    let val = input.value.replace(/\D/g, '').substring(0, 16);
    input.value = val.replace(/(.{4})/g, '$1 ').trim();
    const icon = document.getElementById('card-type-icon');
    if (val.startsWith('4')) icon.className = 'ti ti-brand-visa card-icon';
    else if (val.startsWith('5') || val.startsWith('2')) icon.className = 'ti ti-brand-mastercard card-icon';
    else icon.className = 'ti ti-credit-card card-icon';
}

function formatExpiry(input) {
    let val = input.value.replace(/\D/g, '').substring(0, 4);
    if (val.length >= 2) val = val.substring(0, 2) + ' / ' + val.substring(2);
    input.value = val;
}

function toggleCvvTip() {
    const tip = document.getElementById('cvv-tip');
    tip.style.display = tip.style.display === 'none' ? 'block' : 'none';
}

/* ── Phone formatting ── */
function formatPhone(input) {
    let val = input.value.replace(/\D/g, '').substring(0, 10);
    if (val.length > 3 && val.length <= 6) val = val.substring(0, 3) + '-' + val.substring(3);
    else if (val.length > 6) val = val.substring(0, 3) + '-' + val.substring(3, 6) + '-' + val.substring(6);
    input.value = val;
}

/* ── Bank selection ── */
function selectBank(el) {
    document.querySelectorAll('.bank-account').forEach(b => b.classList.remove('selected'));
    el.classList.add('selected');
}

/* ── Slip upload ── */
function handleSlip(input) {
    if (!input.files.length) return;
    const area = document.getElementById('slip-area');
    const name = document.getElementById('slip-name');
    area.classList.add('has-file');
    name.textContent = '✓ ' + input.files[0].name;
    name.style.display = 'block';
}

/* ── Promo code ── */
const PROMO_CODES = { 'PEER10': 10, 'FIRST20': 20, 'STUDY15': 15 };
let discount = 0;
const BASE = 1225;
const VAT = 0.07;

function applyPromo() {
    const code = document.getElementById('promo-input').value.trim().toUpperCase();
    const result = document.getElementById('promo-result');
    const pct = PROMO_CODES[code];
    if (pct) {
        discount = BASE * (pct / 100);
        const subtotal = BASE - discount;
        const vat = subtotal * VAT;
        const total = subtotal + vat;
        document.getElementById('discount-row').style.display = 'flex';
        document.getElementById('discount-amount').textContent = '−฿' + discount.toFixed(2);
        document.getElementById('vat-amount').textContent = '฿' + vat.toFixed(2);
        document.getElementById('total-amount').textContent = '฿' + total.toFixed(2);
        document.getElementById('btn-pay-now').textContent = '';
        document.getElementById('btn-pay-now').innerHTML = '<i class="ti ti-lock"></i> Pay ฿' + total.toFixed(2) + ' Securely';
        document.getElementById('psc-amount').textContent = '฿' + total.toFixed(2) + ' paid';
        result.className = 'promo-result success';
        result.textContent = '✓ Code applied! ' + pct + '% off — you save ฿' + discount.toFixed(2);
    } else if (code === '') {
        result.className = 'promo-result error';
        result.textContent = 'Please enter a promo code.';
    } else {
        result.className = 'promo-result error';
        result.textContent = '✗ Invalid code. Try PEER10, FIRST20, or STUDY15.';
    }
}

/* ── Payment processing ── */
function processPayment() {
    const btn = document.getElementById('btn-pay-now');
    btn.innerHTML = '<i class="ti ti-loader-2" style="animation:spin 1s linear infinite;"></i> Processing...';
    btn.disabled = true;

    setTimeout(() => {
        // Launch confetti
        launchConfetti();
        // Show success overlay
        document.getElementById('pay-success-overlay').classList.add('active');
    }, 2000);
}

/* ── Confetti ── */
function launchConfetti() {
    const wrap = document.getElementById('confetti-wrap');
    const colors = ['#0077B6', '#22c55e', '#f59e0b', '#ef4444', '#7c3aed', '#fff'];
    for (let i = 0; i < 60; i++) {
        const dot = document.createElement('div');
        dot.className = 'confetti-dot';
        dot.style.cssText = `
        left:${Math.random() * 100}%;
        background:${colors[Math.floor(Math.random() * colors.length)]};
        animation-delay:${Math.random() * 0.8}s;
        animation-duration:${0.8 + Math.random() * 0.8}s;
        width:${6 + Math.random() * 6}px;
        height:${6 + Math.random() * 6}px;
        border-radius:${Math.random() > 0.5 ? '50%' : '2px'};
      `;
        wrap.appendChild(dot);
    }
}

/* ── Download receipt (mock) ── */
function downloadReceipt() {
    const btn = document.querySelector('.btn-psc-download');
    btn.innerHTML = '<i class="ti ti-check"></i> Downloaded!';
    btn.style.background = '#22c55e';
    setTimeout(() => {
        btn.innerHTML = '<i class="ti ti-download"></i> Download Receipt';
        btn.style.background = '';
    }, 2000);
}

/* ── User dropdown ── */
function toggleUserMenu() {
    const drop = document.getElementById('user-dropdown');
    const chevron = document.getElementById('una-chevron');
    const open = drop.classList.toggle('open');
    chevron.style.transform = open ? 'rotate(180deg)' : '';
}
document.addEventListener('click', e => {
    const menuWrap = document.getElementById('user-menu-wrap');
    if (menuWrap && !menuWrap.contains(e.target)) {
        const dropdown = document.getElementById('user-dropdown');
        const chevron = document.getElementById('una-chevron');
        if (dropdown) dropdown.classList.remove('open');
        if (chevron) chevron.style.transform = '';
    }
});

/* ── Section switching ── */
function switchSection(name, btn) {
    document.querySelectorAll('.sp-panel').forEach(p => p.classList.remove('active'));
    document.querySelectorAll('.sp-nav-item').forEach(b => b.classList.remove('active'));
    document.getElementById('panel-' + name).classList.add('active');
    if (btn) btn.classList.add('active');
}

/* ── Photo preview ── */
function previewProfilePhoto(input) {
    if (!input.files.length) return;
    const reader = new FileReader();
    reader.onload = e => {
        const src = e.target.result;
        const el1 = document.getElementById('photo-preview-lg');
        const el2 = document.getElementById('sidebar-avatar');
        const el3 = document.getElementById('una-avatar');
        el1.innerHTML = `<img src="${src}" style="width:100%;height:100%;object-fit:cover;border-radius:50%;" />`;
        el2.innerHTML = `<img src="${src}" style="width:100%;height:100%;object-fit:cover;border-radius:50%;" />`;
        el3.innerHTML = `<img src="${src}" style="width:100%;height:100%;object-fit:cover;border-radius:50%;" />`;
    };
    reader.readAsDataURL(input.files[0]);
}

function removePhoto() {
    ['photo-preview-lg', 'sidebar-avatar', 'una-avatar'].forEach(id => {
        document.getElementById(id).innerHTML = 'AL';
    });
}

/* ── Bio counter ── */
function updateBioCount(el) {
    document.getElementById('bio-count').textContent = el.value.length;
}

/* ── Language picker ── */
function toggleLang(el) { el.classList.toggle('selected'); }

/* ── Password ── */
function togglePwd(id, btn) {
    const input = document.getElementById(id);
    const icon = btn.querySelector('.ti');
    if (input.type === 'password') {
        input.type = 'text'; icon.className = 'ti ti-eye-off';
    } else {
        input.type = 'password'; icon.className = 'ti ti-eye';
    }
}

function checkPwdStrength(val) {
    const rules = {
        length: val.length >= 8,
        upper: /[A-Z]/.test(val),
        number: /[0-9]/.test(val),
        special: /[^A-Za-z0-9]/.test(val)
    };
    const score = Object.values(rules).filter(Boolean).length;
    const colors = ['', '#ef4444', '#f97316', '#f59e0b', '#22c55e'];
    const labels = ['', 'Weak', 'Fair', 'Good', 'Strong'];
    for (let i = 1; i <= 4; i++) {
        const bar = document.getElementById('pws-' + i);
        bar.style.background = i <= score ? colors[score] : '#e5e7eb';
    }
    document.getElementById('pws-label').textContent = val ? labels[score] : 'Enter a password';
    document.getElementById('pws-label').style.color = colors[score] || '#aaa';

    const ruleMap = { 'rule-length': rules.length, 'rule-upper': rules.upper, 'rule-number': rules.number, 'rule-special': rules.special };
    Object.entries(ruleMap).forEach(([id, ok]) => {
        const el = document.getElementById(id);
        el.classList.toggle('passed', ok);
        el.querySelector('.ti').className = ok ? 'ti ti-circle-check' : 'ti ti-circle';
    });
}

function changePassword() {
    const cur = document.getElementById('pwd-current').value;
    const nw = document.getElementById('pwd-new').value;
    const cf = document.getElementById('pwd-confirm').value;
    if (!cur || !nw || !cf) { alert('Please fill in all password fields.'); return; }
    if (nw !== cf) { alert('New passwords do not match.'); return; }
    showToast('Password updated successfully!');
}

/* ── 2FA ── */
function toggle2FA(input) {
    const status = input.closest('.tfa-row').querySelector('.tfa-status');
    if (input.checked) { status.textContent = 'On'; status.className = 'tfa-status on'; }
    else { status.textContent = 'Off'; status.className = 'tfa-status off'; }
}

/* ── Revoke session ── */
function revokeSession(btn) {
    btn.closest('.sec-session').style.opacity = '0.4';
    btn.textContent = 'Revoked';
    btn.disabled = true;
}
function revokeAllSessions() {
    document.querySelectorAll('.sec-session:not(.current)').forEach(s => {
        s.style.opacity = '0.4';
        const btn = s.querySelector('.btn-revoke');
        if (btn) { btn.textContent = 'Revoked'; btn.disabled = true; }
    });
    closeModal();
    showToast('All other devices signed out.');
}

/* ── Modals ── */
function showModal(name) {
    document.getElementById('modal-backdrop').classList.add('active');
    document.querySelectorAll('.sp-modal').forEach(m => m.classList.remove('active'));
    document.getElementById('modal-' + name).classList.add('active');
}
function closeModal() {
    document.getElementById('modal-backdrop').classList.remove('active');
    document.querySelectorAll('.sp-modal').forEach(m => m.classList.remove('active'));
}

/* ── Delete confirm ── */
function checkDeleteConfirm(val) {
    document.getElementById('btn-confirm-delete').disabled = val.trim() !== 'DELETE';
}

/* ── Save sections ── */
function saveSection(name) { showToast('Profile updated successfully!'); }

/* ── Toast ── */
function showToast(msg) {
    const toast = document.getElementById('save-toast');
    toast.innerHTML = '<i class="ti ti-circle-check"></i> ' + msg;
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 3000);
}

const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
let selDate = null, selTime = null;
let currentStep = 1;

/* ── Build date grid ── */
function buildDates() {
    const grid = document.getElementById('date-grid');
    const today = new Date();
    for (let i = 0; i < 14; i++) {
        const d = new Date(today);
        d.setDate(today.getDate() + i);
        const btn = document.createElement('button');
        btn.className = 'date-btn';
        btn.innerHTML = `<span class="day-name">${DAYS[d.getDay()]}</span><span class="day-date">${MONTHS[d.getMonth()]} ${d.getDate()}</span>`;
        const label = DAYS[d.getDay()] + ', ' + MONTHS[d.getMonth()] + ' ' + d.getDate();
        btn.onclick = () => selectDate(btn, label);
        grid.appendChild(btn);
    }
}

function selectDate(btn, label) {
    document.querySelectorAll('.date-btn').forEach(b => b.classList.remove('selected'));
    btn.classList.add('selected');
    selDate = label; selTime = null;
    document.querySelectorAll('.time-btn:not(.unavailable)').forEach(b => b.classList.remove('selected'));
    document.getElementById('time-section').style.display = 'block';
    updateSummary();
}

function selectTime(btn, time) {
    document.querySelectorAll('.time-btn').forEach(b => b.classList.remove('selected'));
    btn.classList.add('selected');
    selTime = time;
    updateSummary();
}

function updateSummary() {
    const bar = document.getElementById('summary-bar');
    const btn = document.getElementById('btn1');
    if (selDate && selTime) {
        document.getElementById('summary-text').textContent = selDate + ' at ' + selTime + ' (60 min)';
        bar.classList.add('visible');
        btn.classList.add('ready');
    } else {
        bar.classList.remove('visible');
        btn.classList.remove('ready');
    }
}

/* ── Stepper ── */
function setDone(n) {
    const s = document.getElementById('s' + n);
    const c = document.getElementById('sc' + n);
    s.className = 'step done';
    c.innerHTML = '<i class="ti ti-check" style="font-size:14px;"></i>';
    if (document.getElementById('sl' + n)) document.getElementById('sl' + n).classList.add('done');
}
function setActive(n) {
    const s = document.getElementById('s' + n);
    const c = document.getElementById('sc' + n);
    s.className = 'step active';
    c.textContent = n;
}
function setIdle(n) {
    const s = document.getElementById('s' + n);
    const c = document.getElementById('sc' + n);
    s.className = 'step';
    c.textContent = n;
    const line = document.getElementById('sl' + (n - 1));
    if (line) line.classList.remove('done');
}

/* ── Navigation ── */
function goStep(n) {
    // Validate before advancing
    if (n === 2 && (!selDate || !selTime)) return;
    if (n === 3) {
        const subj = document.getElementById('subject-select').value;
        if (!subj) return;
        // Populate step 3
        const lenVal = document.getElementById('length-select').value.split('|');
        const hrs = lenVal[0];
        const price = parseFloat(lenVal[1]);
        const hrsLabel = hrs === '1' ? '1 hour' : hrs + ' hours';
        document.getElementById('r-date').textContent = selDate;
        document.getElementById('r-time').textContent = selTime;
        document.getElementById('r-subject').textContent = subj;
        document.getElementById('r-duration').textContent = hrsLabel;
        document.getElementById('r-session-label').textContent = 'Session (' + hrsLabel + ')';
        document.getElementById('r-session-price').textContent = '$' + price.toFixed(2);
        document.getElementById('r-total').textContent = '$' + price.toFixed(2);
    }
    if (n === 4) {
        // Populate confirmed screen
        const subj = document.getElementById('subject-select').value;
        const lenVal = document.getElementById('length-select').value.split('|');
        const hrs = lenVal[0];
        const price = parseFloat(lenVal[1]);
        const hrsLabel = hrs === '1' ? '1 hour' : hrs + ' hours';
        document.getElementById('c-date').textContent = selDate;
        document.getElementById('c-time').textContent = selTime;
        document.getElementById('c-subject').textContent = subj;
        document.getElementById('c-duration').textContent = hrsLabel;
        document.getElementById('c-total').textContent = '$' + price.toFixed(2);
        // Hide nav elements
        document.getElementById('back-bar').style.display = 'none';
        document.getElementById('stepper').style.display = 'none';
    }

    // Update stepper states
    if (n > currentStep) {
        for (let i = currentStep; i < n; i++) {
            if (i <= 3) setDone(i);
        }
    } else {
        for (let i = n; i <= currentStep; i++) {
            if (i <= 3) setIdle(i);
        }
    }
    if (n <= 3) setActive(n);

    // Show/hide panels
    ['step1', 'step2', 'step3'].forEach(s => document.getElementById(s).style.display = 'none');
    document.getElementById('step4').classList.remove('active');
    if (n <= 3) {
        document.getElementById('step' + n).style.display = 'grid';
    } else {
        document.getElementById('step4').classList.add('active');
    }

    currentStep = n;
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function checkStep2() {
    const ok = document.getElementById('subject-select').value !== '';
    document.getElementById('btn2').classList.toggle('ready', ok);
}

// This shared file is also used by pages without the booking calendar.
// Only build the date buttons when the required grid exists.
if (document.getElementById('date-grid')) {
    buildDates();
}

function switchProfileTab(name, btn) {
    document.querySelectorAll('.profile-tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.profile-panel').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById('ptab-' + name).classList.add('active');
}

/* ══════════════════════════════════════
   TUTOR PAYOUT MANAGEMENT
══════════════════════════════════════ */

/* Switch payout sub-tabs */
function switchPayoutTab(name, button) {
    document.querySelectorAll('.payout-subtab').forEach(tab => {
        tab.classList.remove('active');
    });

    document.querySelectorAll('.payout-subpanel').forEach(panel => {
        panel.classList.remove('active');
    });

    button.classList.add('active');

    const selectedPanel = document.getElementById('subpanel-' + name);

    if (selectedPanel) {
        selectedPanel.classList.add('active');
    }
}


/* Open payout form */
function openPayoutForm(name, earnings, commission, payout, key) {
    const payoutForm = document.getElementById('initiate-payout-card');
    const tutorSelect = document.getElementById('ip-tutor');

    tutorSelect.value = key;

    document.getElementById('ip-earnings').value =
        Number(earnings).toLocaleString();

    document.getElementById('ip-commission').value =
        Number(commission).toLocaleString();

    document.getElementById('ip-payout').value =
        Number(payout).toLocaleString();

    payoutForm.style.display = 'block';

    payoutForm.scrollIntoView({
        behavior: 'smooth',
        block: 'start'
    });
}


/* Close payout form */
function closePayoutForm() {
    const payoutForm = document.getElementById('initiate-payout-card');

    if (payoutForm) {
        payoutForm.style.display = 'none';
    }
}


/* Cancel payout */
function cancelPayout() {
    closePayoutForm();
}


/* Update payout amounts when tutor changes */
function updatePayoutForm() {
    const tutorSelect = document.getElementById('ip-tutor');
    const selectedTutor =
        tutorSelect.options[tutorSelect.selectedIndex];

    document.getElementById('ip-earnings').value =
        Number(selectedTutor.dataset.earnings).toLocaleString();

    document.getElementById('ip-commission').value =
        Number(selectedTutor.dataset.commission).toLocaleString();

    document.getElementById('ip-payout').value =
        Number(selectedTutor.dataset.payout).toLocaleString();
}


/* Change destination field based on payout method */
function updateMethodFields() {
    const method = document.getElementById('ip-method').value;
    const label = document.getElementById('ip-method-label');
    const input = document.getElementById('ip-method-value');

    if (method === 'PromptPay') {
        label.textContent = 'PromptPay ID / Phone';
        input.placeholder = '081-234-5678';
    } else if (method === 'Bank Transfer') {
        label.textContent = 'Bank Account Number';
        input.placeholder = 'xxx-x-12345-x';
    } else {
        label.textContent = 'TrueMoney Phone';
        input.placeholder = '081-234-5678';
    }

    input.value = '';
}


/* ══════════════════════════════════════
   PAYOUT DATA STORAGE
══════════════════════════════════════ */

const PAYOUT_STORAGE_KEY = 'peerTutorProcessingPayouts';

const payoutData = {
    processing: []
};


/* Load saved payout records */
try {
    const savedPayouts =
        localStorage.getItem(PAYOUT_STORAGE_KEY);

    payoutData.processing =
        savedPayouts ? JSON.parse(savedPayouts) : [];
} catch (error) {
    payoutData.processing = [];
}


/* Find the next payout reference number */
let payoutRefCounter =
    payoutData.processing.reduce((highest, payout) => {
        const referenceNumber = Number(
            String(payout.reference || '').replace(/\D/g, '')
        );

        return Math.max(highest, referenceNumber + 1);
    }, 42);


/* Save payout records */
function savePayoutData() {
    try {
        localStorage.setItem(
            PAYOUT_STORAGE_KEY,
            JSON.stringify(payoutData.processing)
        );
    } catch (error) {
        console.warn(
            'Payout data could not be saved.',
            error
        );
    }
}


/* ══════════════════════════════════════
   CONFIRM TRANSFER
══════════════════════════════════════ */

function confirmPayout() {
    const tutorSelect =
        document.getElementById('ip-tutor');

    const selectedTutor =
        tutorSelect.options[tutorSelect.selectedIndex];

    const tutor = selectedTutor.text.trim();
    const tutorKey = tutorSelect.value;

    const amount =
        document.getElementById('ip-payout').value;

    const method =
        document.getElementById('ip-method').value;

    const destination =
        document.getElementById('ip-method-value')
            .value.trim();

    const confirmButton =
        document.querySelector(
            '#initiate-payout-card .btn-ip-confirm'
        );


    /* Check payment destination */
    if (!destination) {
        alert(
            'Please enter the tutor payment destination.'
        );

        document
            .getElementById('ip-method-value')
            .focus();

        return;
    }


    /* Prevent duplicate payout */
    const alreadyProcessing =
        payoutData.processing.some(
            payout => payout.key === tutorKey
        );

    if (alreadyProcessing) {
        alert(
            tutor +
            ' already has a payout in the Processing tab.'
        );

        return;
    }


    const reference =
        'PT-PAY-00' + payoutRefCounter++;


    /* Show loading state */
    confirmButton.disabled = true;

    confirmButton.innerHTML =
        '<i class="ti ti-loader-2 payout-spinner"></i>' +
        ' Processing...';


    setTimeout(() => {
        const newPayout = {
            key: tutorKey,
            tutor: tutor,
            amount: amount,
            method: method,
            destination: destination,
            reference: reference,
            initiated: new Date().toISOString(),
            status: 'processing'
        };


        /* Store payout in JavaScript array */
        payoutData.processing.unshift(newPayout);


        /* Save payout in browser storage */
        savePayoutData();


        /* Remove Pending row and add Processing row */
        addProcessingPayout(newPayout);


        /* Update success modal */
        const modalTitle =
            document.getElementById('pm-title');

        const modalMessage =
            document.getElementById('pm-message');

        const modalReference =
            document.getElementById('pm-ref');

        if (modalTitle) {
            modalTitle.textContent =
                'Transfer Initiated!';
        }

        if (modalMessage) {
            modalMessage.textContent =
                '฿' + amount +
                ' for ' + tutor +
                ' was submitted via ' + method +
                '. It will remain in Processing until completion.';
        }

        if (modalReference) {
            modalReference.textContent = reference;
        }


        /* Show success modal */
        const modal =
            document.getElementById(
                'payout-modal-overlay'
            );

        if (modal) {
            modal.classList.add('active');
        }


        closePayoutForm();

        confirmButton.disabled = false;

        confirmButton.innerHTML =
            '<i class="ti ti-send"></i>' +
            ' Confirm Transfer';

    }, 700);
}


/* ══════════════════════════════════════
   MOVE PAYOUT TO PROCESSING
══════════════════════════════════════ */

function addProcessingPayout(payout) {
    /*
     * Remove the tutor from Pending Payouts.
     * Example: prow-sarah
     */
    const pendingRow =
        document.getElementById(
            'prow-' + payout.key
        );

    if (pendingRow) {
        pendingRow.remove();
    }


    /* Disable the tutor in the selection list */
    const tutorOption =
        document.querySelector(
            '#ip-tutor option[value="' +
            payout.key +
            '"]'
        );

    if (tutorOption) {
        tutorOption.disabled = true;
    }


    const processingTable =
        document.getElementById(
            'processing-tbody'
        );

    if (!processingTable) {
        return;
    }


    /* Do not display duplicate records */
    const existingRecord =
        processingTable.querySelector(
            '[data-reference="' +
            payout.reference +
            '"]'
        );

    if (existingRecord) {
        return;
    }


    const initials =
        payout.tutor
            .split(/\s+/)
            .map(part => part.charAt(0))
            .join('')
            .slice(0, 2)
            .toUpperCase();


    const initiatedDate =
        new Date(payout.initiated)
            .toLocaleDateString('en-US', {
                month: 'short',
                day: 'numeric',
                year: 'numeric'
            });


    const row =
        document.createElement('tr');

    row.dataset.reference =
        payout.reference;


    row.innerHTML = `
        <td class="pt-tutor-cell">
            <div class="pt-avatar pt-avatar-processing">
                ${initials}
            </div>
            ${payout.tutor}
        </td>

        <td class="pt-amount">
            ฿${payout.amount}
        </td>

        <td>
            ${payout.method}
        </td>

        <td>
            ${initiatedDate}
        </td>

        <td>
            <span class="pt-status processing">
                Processing
            </span>

            <div class="processing-ref">
                ${payout.reference}
            </div>
        </td>
    `;


    /* Add newest record at the top */
    processingTable.prepend(row);


    updatePendingPayoutInformation();
}


/* ══════════════════════════════════════
   UPDATE PENDING BADGE AND TOTALS
══════════════════════════════════════ */

function updatePendingPayoutInformation() {
    const pendingRows =
        document.querySelectorAll(
            '#pending-tbody tr[id^="prow-"]'
        );


    /* Update pending badge */
    const badge =
        document.getElementById(
            'payout-pending-badge'
        );

    if (badge) {
        badge.textContent =
            pendingRows.length;
    }


    const totals = {
        earnings: 0,
        commission: 0,
        payout: 0
    };


    pendingRows.forEach(row => {
        totals.earnings += Number(
            row.cells[1].textContent
                .replace(/[^0-9.]/g, '')
        ) || 0;

        totals.commission += Number(
            row.cells[2].textContent
                .replace(/[^0-9.]/g, '')
        ) || 0;

        totals.payout += Number(
            row.cells[3].textContent
                .replace(/[^0-9.]/g, '')
        ) || 0;
    });


    const formatBaht =
        value => '฿' + value.toLocaleString();


    const earningsElement =
        document.getElementById(
            'pending-total-earnings'
        );

    const commissionElement =
        document.getElementById(
            'pending-total-commission'
        );

    const payoutElement =
        document.getElementById(
            'pending-total-payout'
        );


    if (earningsElement) {
        earningsElement.textContent =
            formatBaht(totals.earnings);
    }

    if (commissionElement) {
        commissionElement.textContent =
            formatBaht(totals.commission);
    }

    if (payoutElement) {
        payoutElement.textContent =
            formatBaht(totals.payout);
    }
}


/* ══════════════════════════════════════
   RESTORE DATA AFTER PAGE REFRESH
══════════════════════════════════════ */

function restoreProcessingPayouts() {
    const processingTable =
        document.getElementById(
            'processing-tbody'
        );

    if (!processingTable) {
        return;
    }


    /*
     * Reverse temporarily because prepend() places
     * every restored item at the top.
     */
    [...payoutData.processing]
        .reverse()
        .forEach(payout => {
            addProcessingPayout(payout);
        });


    updatePendingPayoutInformation();
}


if (document.readyState === 'loading') {
    document.addEventListener(
        'DOMContentLoaded',
        restoreProcessingPayouts
    );
} else {
    restoreProcessingPayouts();
}


/* ══════════════════════════════════════
   SUCCESS MODAL
══════════════════════════════════════ */

function closePayoutModal() {
    const modal =
        document.getElementById(
            'payout-modal-overlay'
        );

    if (modal) {
        modal.classList.remove('active');
    }
}


function viewProcessingPayouts() {
    closePayoutModal();

    const processingButton =
        document.querySelector(
            '[onclick*="switchPayoutTab(\'processing\'"]'
        );

    if (processingButton) {
        switchPayoutTab(
            'processing',
            processingButton
        );
    }

    const payoutTab =
        document.getElementById('tab-payouts');

    if (payoutTab) {
        payoutTab.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });
    }
}

/* ══════════════════════════════
   STUDENT PAYMENTS TAB
══════════════════════════════ */

/* ── Filter by status tab ── */
function filterPayments(status, btn) {
    document.querySelectorAll('.sp-filter-tab').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    document.querySelectorAll('.sp-row').forEach(row => {
        row.style.display = (status === 'all' || row.dataset.status === status) ? '' : 'none';
    });
}

/* ── Search ── */
function searchPayments(q) {
    const query = q.toLowerCase();
    document.querySelectorAll('.sp-row').forEach(row => {
        row.style.display = row.innerText.toLowerCase().includes(query) ? '' : 'none';
    });
}

/* ── Filter by method ── */
function filterByMethod(method) {
    document.querySelectorAll('.sp-row').forEach(row => {
        row.style.display = (!method || row.dataset.method === method) ? '' : 'none';
    });
}

/* ── Update payment status ── */
function updatePaymentStatus(id, newStatus) {
    const row = document.getElementById('sprow-' + id);
    const badge = row.querySelector('.sp-status-badge');
    const cell = row.querySelector('.sp-action-cell');

    // Update badge
    badge.className = 'sp-status-badge ' + newStatus;
    const labels = { confirmed: 'Confirmed', failed: 'Failed', pending: 'Pending', processing: 'Processing' };
    badge.textContent = labels[newStatus];

    // Update row dataset
    row.dataset.status = newStatus;

    // Swap action buttons
    if (newStatus === 'confirmed') {
        row.style.opacity = '0.85';
        cell.innerHTML = `
      <button class="btn-sp-revert" onclick="updatePaymentStatus('${id}','pending')">
        <i class="ti ti-refresh"></i> Revert
      </button>
      <button class="btn-sp-receipt" onclick="downloadReceipt('${id}')">
        <i class="ti ti-receipt"></i> Receipt
      </button>`;
        showPaymentToast('Payment confirmed — session unlocked for student.', 'success');
    } else if (newStatus === 'failed') {
        row.style.opacity = '0.75';
        row.style.background = '#fff8f8';
        cell.innerHTML = `
      <button class="btn-sp-confirm" onclick="updatePaymentStatus('${id}','confirmed')">
        <i class="ti ti-circle-check"></i> Re-verify
      </button>
      <button class="btn-sp-notify" onclick="notifyStudent('${id}','Student')">
        <i class="ti ti-send"></i> Notify
      </button>`;
        showPaymentToast('Payment rejected — student will be notified.', 'error');
    } else if (newStatus === 'pending') {
        row.style.opacity = '';
        row.style.background = '';
        cell.innerHTML = `
      <button class="btn-sp-confirm" onclick="updatePaymentStatus('${id}','confirmed')">
        <i class="ti ti-circle-check"></i> Confirm
      </button>
      <button class="btn-sp-reject" onclick="updatePaymentStatus('${id}','failed')">
        <i class="ti ti-circle-x"></i> Reject
      </button>`;
        showPaymentToast('Payment reverted to Pending.', 'warn');
    }

    // Update pending badge count on tab
    updatePendingBadge();
    closeSlipModal();
}

/* ── Update pending count badge on tab ── */
function updatePendingBadge() {
    const count = document.querySelectorAll('.sp-row[data-status="pending"]').length;
    const badge = document.querySelector('#tab-payments .pending-count');
    if (badge) badge.textContent = count;
    // Also update the main tab badge
    const tabBadge = document.querySelector('[onclick*="payments"] .tab-badge');
    if (tabBadge) tabBadge.textContent = count;
}

/* ── View slip modal ── */
let currentSlipId = null;
function viewSlip(id, student, amount, method) {
    currentSlipId = id;
    const row = document.getElementById('sprow-' + id);
    const status = row.dataset.status;
    const ref = row.querySelector('.sp-ref').textContent;
    const submitted = row.querySelector('.sp-submitted').textContent;

    document.getElementById('slip-ph-name').textContent = student;
    document.getElementById('sm-ref').textContent = ref;
    document.getElementById('sm-student').textContent = student;
    document.getElementById('sm-amount').textContent = amount;
    document.getElementById('sm-method').textContent = method;
    document.getElementById('sm-submitted').textContent = submitted;
    document.getElementById('sm-status').innerHTML =
        `<span class="sp-status-badge ${status}">${status.charAt(0).toUpperCase() + status.slice(1)}</span>`;
    document.getElementById('sm-note').value = '';

    // Wire confirm/reject buttons in modal
    document.getElementById('btn-sm-confirm').onclick = () => updatePaymentStatus(id, 'confirmed');
    document.getElementById('btn-sm-reject').onclick = () => updatePaymentStatus(id, 'failed');

    document.getElementById('slip-modal-overlay').classList.add('active');
    document.getElementById('slip-modal').classList.add('active');
}

function closeSlipModal() {
    document.getElementById('slip-modal-overlay').classList.remove('active');
    document.getElementById('slip-modal').classList.remove('active');
}

/* ── Notify student ── */
function notifyStudent(id, name) {
    showPaymentToast(`Notification sent to ${name} to resubmit payment.`, 'warn');
}

/* ── Download receipt ── */
function downloadReceipt(id) {
    showPaymentToast('Receipt downloaded successfully.', 'success');
}

/* ── Toast ── */
function showPaymentToast(msg, type = 'success') {
    const toast = document.getElementById('sp-toast');
    const msgEl = document.getElementById('sp-toast-msg');
    toast.className = 'sp-toast ' + type;
    const icons = { success: 'ti-circle-check', error: 'ti-circle-x', warn: 'ti-alert-circle' };
    toast.querySelector('.ti').className = 'ti ' + (icons[type] || 'ti-circle-check');
    msgEl.textContent = msg;
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 3500);
}